I created the NYTimes App. With my app you can search NYTimes articles. Articlesare displayed with a headline, snippet, and the date of  publication

I have completed 3 of the 4 requirements, my app:

1)Integrates the New York Times API
2)Displays the articles with a collection view
3)Has search functionality

I unfortunately did not have time to complete the detail view :( as I have been swamped with work. I hope this is acceptable
:) Alexei Tulloch
